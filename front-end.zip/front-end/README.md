Here is our front-end.
The basic framework is Bootstrap FullSlider.